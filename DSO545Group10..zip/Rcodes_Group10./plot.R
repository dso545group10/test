
# new data 

crimes <- data.frame(state = tolower(rownames(USArrests)), USArrests)


data=data("crime")

install.packages("qmap")

library(ggmap)

qmap("Houston", zoom = 14)

data=data("crime")

data=crime

LA = get_map(location = "los angeles", zoom = 14, color = "bw")

LAMap = ggmap(LA)

LAMap +
  stat_density2d(data = dat2b,
                 aes(x= lon, y = lat, fill = ..level..),
                 geom = "polygon", alpha = 0.5) +
  scale_fill_gradient(low= "white", high = "#bd0026") +
  facet_wrap(~year, nrow = 2)


years <- seq(1975,1989,2)

db <- data.frame(Dallas=c( 25, 28, 27, 29, 31, 33, 35, 37),
                 Houston=c( 33, 38, 43, 48, 53, 58, 63, 68),
                 Lubbock=c( 28, 29, 31, 33, 35, 37, 39, 41),
                 Austin= c(22, 24, 26, 28, 30, 32, 34, 36),
                 San_Antonio= c(31, 32, 33, 34, 35, 36, 37, 38)
)


### plot housing price for each year

setwd("F:/DSO545")

data1=read.csv("ACS_2011_5YR_Final.csv")
data2=read.csv("ACS_2012_5YR_Final.csv")
data3=read.csv("ACS_2013_5YR_Final.csv")
data4=read.csv("ACS_2014_5YR_Final.csv")
data5=read.csv("ACS_2015_5YR_Final.csv")


data=merge(data1,data2,by="GEO.id2")

data=merge(data,data3,by="GEO.id2")

data=merge(data,data4,by="GEO.id2")

dat=merge(data,data5,by="GEO.id2",all.x=TRUE) # get the big final data

write.csv(dat, file = "ACS_5YR_Cleaned_allyears.csv")


## for house value without mortgage


dat1=dat[,c("VH_NM","VH_NM11","VH_NM12","VH_NM13","VH_NM14","GEO.id2")]




dat1[1:2]

# arrange several columns into one column

library(reshape2)
dat2b <- melt(dat1, id.vars=6)

dat2b$year[dat2b$variable=="VH_NM"] = 2015

dat2b$year[dat2b$variable=="VH_NM14"] = 2014

dat2b$year[dat2b$variable=="VH_NM13"] = 2013

dat2b$year[dat2b$variable=="VH_NM12"] = 2012

dat2b$year[dat2b$variable=="VH_NM11"] = 2011


dat2b=dat2b[,-2]

dat2b_2015 = subset(dat2b,year==2015)

dat2b_2015=dat2b_2015[,-2]

library(ggplot2)

ggplot(data = dat2b_2015, aes(x = year, y =GEO.id2 )) +
  geom_tile(aes(fill = value)) 

library(zipcode)

data("zipcode")

dat2b1=merge(dat2b,zipcode,by.x="GEO.id2",by.y="zip",all.x = TRUE)

library(ggmap)

LA = get_map(location = "los angeles", zoom = 14, color = "bw")

LAMap = ggmap(LA)

LAMap +
  stat_density2d(data = dat2b1,
                 aes(x= lon, y = lat, fill = ..level..),
                 geom = "polygon", alpha = 0.5) +
  scale_fill_gradient(low= "white", high = "#bd0026") +
  facet_wrap(~year, nrow = 2)


# transpose the data


dat2=data.frame(t(dat1))  

colnames(dat2)=as.matrix(dat2[6,])

dat2=dat2[-6,]

dat2





# plot the heated map for house price without mortgage

dat2=dat2[c(2,3,4,5,1),]

years=seq(2011,2015,1)


ggplot(data = .team_data, aes(x = metrics, y = teams)) +
  geom_tile(aes(fill = performance)) 







### combine zipcode

library(zipcode)

data("zipcode")

dat1=merge(dat,zipcode,by.x = "GEO.id2",by.y="zip")


dat2=dat1[,c("NH_NM11","GEO.id2","longitude","latitude")]


dat3=dat1[,c("NH_NM12","GEO.id2","longitude","latitude")]


ggplot(dat2) + geom_point(aes(x=longitude, y=latitude, colour=region))+facet_wrap(~day, nrow = 2)
