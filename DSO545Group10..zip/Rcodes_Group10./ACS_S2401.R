setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 90000-90500")

data1 = read.csv("ACS_15_5YR_S2401_with_ann.csv")

setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 90500-91500")

data2 = read.csv("ACS_15_5YR_S2401_with_ann.csv")

setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 91500-92000")

data3 = read.csv("ACS_15_5YR_S2401_with_ann.csv")

data2 = data2[-1,]

data3 = data3[-1,]

data = rbind(data1, data2, data3)

library(dplyr)

keeps = c("GEO.id2", "HC01_EST_VC01", "HC01_EST_VC02", 
          "HC01_EST_VC10", "HC01_EST_VC11", "HC01_EST_VC12",
          "HC01_EST_VC13", "HC01_EST_VC14")

data = data[keeps]

setwd("~/Documents/DSO 545/Project/Data Collection/2015 ACS/S2401")

write.csv(data, file = "ACS_2015_5YR_S2401_Cleaned_Final.csv")
