setwd("D:/project_new/2015 ACS/ACS_clean1/S2401_clean")

data=read.csv("ACS_2014_5YR_S2401_Cleaned.csv")


### sum the columns in 2015  for S1501

setwd("D:/project_new/2015 ACS/ACS_clean1/S1501_clean")





#####

setwd("D:/project_new/2015 ACS/ACS_clean1/2011")


S1501 = read.csv("ACS_2011_5YR_S1501_Cleaned.csv")
S1901 = read.csv("ACS_2011_5YR_S1901_Cleaned.csv")
S2301 = read.csv("ACS_2011_5YR_S2301_Cleaned.csv")
S2401 = read.csv("ACS_2011_5YR_S2401_Cleaned.csv")
S2403 = read.csv("ACS_2011_5YR_S2403_Cleaned.csv")
S2506 = read.csv("ACS_2011_5YR_S2506_Cleaned.csv")
S2507 = read.csv("ACS_2011_5YR_S2507_Cleaned.csv")



S1501 = S1501[,-1]
S1901 = S1901[,-1]
S2301 = S2301[,-1]
S2401 = S2401[,-1]
S2403 = S2403[,-1]
S2506 = S2506[,-1]
S2507 = S2507[,-1]


data1 = merge(S1501, S1901, by = "GEO.id2")
data2 = merge(data1, S2301, by = "GEO.id2")
data3 = merge(data2, S2401, by = "GEO.id2")
data4 = merge(data3, S2403, by = "GEO.id2")
data5 = merge(data4, S2506, by = "GEO.id2")
data6 = merge(data5, S2507, by = "GEO.id2")

write.csv(data6, file = "ACS_2011_5YR_Final.csv")


# renew data 2015 for S1501

setwd("D:/project_new/2015 ACS/ACS_clean1/2015")

data=read.csv("ACS_2015_5YR_Final.csv")

S1501 = read.csv("ACS_2015_5YR_S1501_Cleaned.csv")
  
S1501 = S1501[,-1]

data1 = merge(S1501, data, by = "GEO.id2")

write.csv(data1, file = "ACS_2015_5YR_Final.csv")


# merge five years togather

setwd("F:/DSO545")

data1=read.csv("ACS_2011_5YR_Final.csv")
data2=read.csv("ACS_2012_5YR_Final.csv")
data3=read.csv("ACS_2013_5YR_Final.csv")
data4=read.csv("ACS_2014_5YR_Final.csv")
data5=read.csv("ACS_2015_5YR_Final.csv")

data6=merge(data6,data4,by = "GEO.id2")


