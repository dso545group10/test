setwd("D:/project_new")

# READ excel---gross income

library(xlsx)

d=read.xlsx("grossincomeforla.xlsx.",3)





# S0101

setwd("G:/project_new/ACS_clean/S0101_clean")

data =read.csv("ACS_2011_5YR_S0101_Cleaned.csv")

names=read.csv("ACS_2015_5YR_S0101_metadata_cleaned.csv")


colnames(data)=names[,"NEW_2011"]



write.csv(data, file = "ACS_2011_5YR_S0101_Cleaned.csv")


# S1501

setwd("D:/project_new/ACS_clean/S1501_clean")

data =read.csv("ACS_2011_5YR_S1501_Cleaned.csv")

names=read.csv("ACS_2015_5YR_S1501_metadata_cleaned.csv")


colnames(data)=names[1:14,"NEW_2011"]


write.csv(data, file = "ACS_2011_5YR_S1501_Cleaned.csv")


# S1901

setwd("D:/project_new/ACS_clean/S1901_clean")

data =read.csv("ACS_2015_5YR_S1901_Cleaned.csv")

colnames(data)=paste("19ic",seq(1,50,1),"_2015",sep="")

write.csv(data, file = "ACS_2015_5YR_S1901_Cleaned.csv")


# S2301


setwd("D:/project_new/ACS_clean/S2301_clean")

data =read.csv("ACS_2011_5YR_S2301_Cleaned.csv")

colnames(data)=paste("23lab",seq(1,38,1),"_2011",sep="")

write.csv(data, file = "ACS_2011_5YR_S2301_Cleaned.csv")

# S2401

setwd("D:/project_new/ACS_clean/S2401_clean")

data =read.csv("ACS_2015_5YR_S2401_Cleaned.csv")

colnames(data)=paste("24oc",seq(1,19,1),"_2015",sep="")

write.csv(data, file = "ACS_2015_5YR_S2401_Cleaned.csv")



#S2403

setwd("D:/project_new/ACS_clean/S2403_clean")

data =read.csv("ACS_2011_5YR_S2403_Cleaned.csv")

colnames(data)=paste("24art",seq(1,18,1),"_2011",sep="")

write.csv(data, file = "ACS_2011_5YR_S2403_Cleaned.csv")


# S2506

setwd("D:/project_new/ACS_clean/S2506_clean")

data =read.csv("ACS_2015_5YR_S2506_Cleaned.csv")

colnames(data)=paste("25hou",seq(1,4,1),"_2015",sep="")

write.csv(data, file = "ACS_2015_5YR_S2506_Cleaned.csv")

# S2507

setwd("D:/project_new/ACS_clean/S2507_clean")

data =read.csv("ACS_2011_5YR_S2507_Cleaned.csv")

colnames(data)=paste("25huw",seq(1,4,1),"_2011",sep="")

write.csv(data, file = "ACS_2011_5YR_S2507_Cleaned.csv")




