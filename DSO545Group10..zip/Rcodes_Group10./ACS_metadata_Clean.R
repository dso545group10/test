setwd("~/Documents/DSO 545/Project/Data Collection/2015 ACS/S0101")

data = read.csv("ACS_15_5YR_S0101_metadata.csv")

library(dplyr)

data = data %>%
  filter(GEO.id %in% c("GEO.id2", 
                       "HC01_EST_VC01", "HC02_EST_VC01", "HC03_EST_VC01",
                       "HC01_EST_VC03", "HC01_EST_VC04","HC01_EST_VC05",
                       "HC01_EST_VC06", "HC01_EST_VC07", "HC01_EST_VC08",
                       "HC01_EST_VC09", "HC01_EST_VC10", "HC01_EST_VC11",
                       "HC01_EST_VC12", "HC01_EST_VC13", "HC01_EST_VC14",
                       "HC01_EST_VC15", "HC01_EST_VC16", "HC01_EST_VC17",
                       "HC01_EST_VC18", "HC01_EST_VC19", "HC01_EST_VC20"))

write.csv(data, file = "ACS_2015_5YR_S0101_metadata_cleaned.csv")
