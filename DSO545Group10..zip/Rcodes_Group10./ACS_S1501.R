setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 90000-90500")

data1 = read.csv("ACS_15_5YR_S1501_with_ann.csv")

setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 90500-91500")

data2 = read.csv("ACS_15_5YR_S1501_with_ann.csv")

setwd("~/Documents/DSO 545/Project/Data Collection/2015-Zip 91500-92000")

data3 = read.csv("ACS_15_5YR_S1501_with_ann.csv")

data2 = data2[-1,]

data3 = data3[-1,]

data = rbind(data1, data2, data3)

library(dplyr)

keeps = c("GEO.id2", "HC01_EST_VC04", 
         "HC01_EST_VC05", "HC01_EST_VC06", "HC01_EST_VC21", 
         "HC01_EST_VC22", "HC01_EST_VC25", "HC01_EST_VC26", 
         "HC01_EST_VC29", "HC01_EST_VC30", "HC01_EST_VC33", 
         "HC01_EST_VC34")

data = data[keeps]

data = data[-1,]

data$HC01_EST_VC04 = as.numeric(data$HC01_EST_VC04)
data$HC01_EST_VC05 = as.numeric(data$HC01_EST_VC05)
data$HC01_EST_VC21 = as.numeric(data$HC01_EST_VC21)
data$HC01_EST_VC25 = as.numeric(data$HC01_EST_VC25)
data$HC01_EST_VC29 = as.numeric(data$HC01_EST_VC29)
data$HC01_EST_VC33 = as.numeric(data$HC01_EST_VC33)
data$HC01_EST_VC06 = as.numeric(data$HC01_EST_VC06)
data$HC01_EST_VC22 = as.numeric(data$HC01_EST_VC22)
data$HC01_EST_VC26 = as.numeric(data$HC01_EST_VC26)
data$HC01_EST_VC30 = as.numeric(data$HC01_EST_VC30)
data$HC01_EST_VC34 = as.numeric(data$HC01_EST_VC34)

data$HS_H = data$HC01_EST_VC04 + data$HC01_EST_VC05 + 
  data$HC01_EST_VC21 + data$HC01_EST_VC25 + data$HC01_EST_VC29 +
  data$HC01_EST_VC33

data$BC_H = data$HC01_EST_VC06 + data$HC01_EST_VC22 +
  data$HC01_EST_VC26 + data$HC01_EST_VC30 + data$HC01_EST_VC34

keep_final = c("GEO.id2", "HS_H", "BC_H")

data = data[keep_final]

setwd("~/Documents/DSO 545/Project/Data Collection/2015 ACS/S1501")

write.csv(data, file = "ACS_2015_5YR_S1501_Cleaned_Final.csv")

