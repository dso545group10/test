S1501 = read.csv("ACS_2015_5YR_S1501_Cleaned_Final.csv")
S1901 = read.csv("ACS_2015_5YR_S1901_Cleaned_Final.csv")
S2301 = read.csv("ACS_2015_5YR_S2301_Cleaned_Final.csv")
S2401 = read.csv("ACS_2015_5YR_S2401_Cleaned_Final.csv")
S2403 = read.csv("ACS_2015_5YR_S2403_Cleaned_Final.csv")
S2506 = read.csv("ACS_2015_5YR_S2506_Cleaned_Final.csv")
S2507 = read.csv("ACS_2015_5YR_S2507_Cleaned_Final.csv")

S1501 = S1501[,-1]
S1901 = S1901[,-1]
S2301 = S2301[,-1]
S2401 = S2401[,-1]
S2403 = S2403[,-1]
S2506 = S2506[,-1]
S2507 = S2507[,-1]


data1 = merge(S1501, S1901, by = "GEO.id2")
data2 = merge(data1, S2301, by = "GEO.id2")
data3 = merge(data2, S2401, by = "GEO.id2")
data4 = merge(data3, S2403, by = "GEO.id2")
data5 = merge(data4, S2506, by = "GEO.id2")
data6 = merge(data5, S2507, by = "GEO.id2")

write.csv(data6, file = "ACS_2015_5YR_Final.csv")
