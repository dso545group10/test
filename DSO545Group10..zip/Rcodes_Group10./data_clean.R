
# S0101


data =read.csv("ACS_15_5YR_S0101.csv")

library(dplyr)

keeps = c("GEO.id2", 
          "HC01_EST_VC01", "HC02_EST_VC01", "HC03_EST_VC01",
          "HC01_EST_VC03", "HC01_EST_VC04","HC01_EST_VC05",
          "HC01_EST_VC06", "HC01_EST_VC07", "HC01_EST_VC08",
          "HC01_EST_VC09", "HC01_EST_VC10", "HC01_EST_VC11",
          "HC01_EST_VC12", "HC01_EST_VC13", "HC01_EST_VC14",
          "HC01_EST_VC15", "HC01_EST_VC16", "HC01_EST_VC17",
          "HC01_EST_VC18", "HC01_EST_VC19", "HC01_EST_VC20")

data = data[keeps]

write.csv(data, file = "ACS_2015_5YR_S0101_Cleaned.csv")






# S1501

setwd("E:/project_new/S1501")

data = read.csv("ACS_11_5YR_S1501_with_ann.csv")


keeps = c("GEO.id2", "HC01_EST_VC02",
          "HC01_EST_VC03",  
          "HC01_EST_VC04",
          "HC01_EST_VC05", 
          "HC01_EST_VC20", 
          "HC01_EST_VC21", 
          "HC01_EST_VC24", 
          "HC01_EST_VC25", 
          "HC01_EST_VC28", 
          "HC01_EST_VC29", 
          "HC01_EST_VC32", 
          "HC01_EST_VC33")

data = data[keeps]

write.csv(data, file = "ACS_2011_5YR_S1501_Cleaned.csv")

# S1901

setwd("E:/project_new/S1901")

data = read.csv("ACS_11_5YR_S1901_with_ann.csv")


library(dplyr)

keeps = c("GEO.id2", "HC01_EST_VC01", "HC02_EST_VC01",
          "HC03_EST_VC01", "HC04_EST_VC01",
          "HC01_EST_VC02", "HC02_EST_VC02",
          "HC03_EST_VC02", "HC04_EST_VC02",
          "HC01_EST_VC03", "HC02_EST_VC03",
          "HC03_EST_VC03", "HC04_EST_VC03",
          "HC01_EST_VC04", "HC02_EST_VC04",
          "HC03_EST_VC04", "HC04_EST_VC04",
          "HC01_EST_VC05", "HC02_EST_VC05",
          "HC03_EST_VC05", "HC04_EST_VC05",
          "HC01_EST_VC06", "HC02_EST_VC06",
          "HC03_EST_VC06", "HC04_EST_VC06",
          "HC01_EST_VC07", "HC02_EST_VC07",
          "HC03_EST_VC07", "HC04_EST_VC07",
          "HC01_EST_VC08", "HC02_EST_VC08",
          "HC03_EST_VC08", "HC04_EST_VC08",
          "HC01_EST_VC09", "HC02_EST_VC09",
          "HC03_EST_VC09", "HC04_EST_VC09",
          "HC01_EST_VC10", "HC02_EST_VC10",
          "HC03_EST_VC10", "HC04_EST_VC10",
          "HC01_EST_VC11", "HC02_EST_VC11",
          "HC03_EST_VC11", "HC04_EST_VC11",
          "HC01_EST_VC13", "HC02_EST_VC13",
          "HC03_EST_VC13", "HC04_EST_VC13")

data = data[keeps]


write.csv(data, file = "ACS_2011_5YR_S1901_Cleaned.csv")


###############################################################

# S2301


setwd("D:/project_new/S2301")

data = read.csv("ACS_11_5YR_S2301_with_ann.csv")


keeps = c("GEO.id2", "HC01_EST_VC01", "HC02_EST_VC01",
          "HC03_EST_VC01", "HC04_EST_VC01",
          "HC01_EST_VC03", "HC02_EST_VC03",
          "HC03_EST_VC03", "HC04_EST_VC03",
          "HC01_EST_VC04", "HC02_EST_VC04",
          "HC03_EST_VC04", "HC04_EST_VC04",
          "HC01_EST_VC05", "HC02_EST_VC05",
          "HC03_EST_VC05", "HC04_EST_VC05",
          "HC01_EST_VC06", "HC02_EST_VC06",
          "HC03_EST_VC06", "HC04_EST_VC06",
          "HC01_EST_VC07", "HC02_EST_VC07",
          "HC03_EST_VC07", "HC04_EST_VC07",
          "HC01_EST_VC08", "HC02_EST_VC08",
          "HC03_EST_VC08", "HC04_EST_VC08",
          "HC01_EST_VC09", "HC02_EST_VC09",
          "HC03_EST_VC09", "HC04_EST_VC09",
          "HC01_EST_VC31", "HC02_EST_VC31",
          "HC03_EST_VC31", "HC04_EST_VC31")

data = data[keeps]

write.csv(data, file = "ACS_2011_5YR_S2301_Cleaned.csv")



# S2401

setwd("E:/project_new/S2401")

data=read.csv("ACS_11_5YR_S2401_with_ann.csv")


keeps = c("GEO.id2", "HC01_EST_VC01", "HC01_EST_VC02", 
          "HC01_EST_VC03", "HC01_EST_VC04",
          "HC01_EST_VC05", "HC01_EST_VC06",
          "HC01_EST_VC07", "HC01_EST_VC08",
          "HC01_EST_VC09", "HC01_EST_VC10",
          "HC01_EST_VC11", "HC01_EST_VC12",
          "HC01_EST_VC13", "HC01_EST_VC14",
          "HC01_EST_VC15", "HC01_EST_VC16",
          "HC01_EST_VC17")

data = data[keeps]

write.csv(data, file = "ACS_2011_5YR_S2401_Cleaned.csv")



###############################################################

# S2403

setwd("E:/project_new/S2403")

data = read.csv("ACS_11_5YR_S2403_with_ann.csv")


keeps = c("GEO.id2", "HC01_EST_VC01", "HC01_EST_VC02", 
          "HC01_EST_VC05", "HC01_EST_VC06",
          "HC01_EST_VC07", "HC01_EST_VC08",
          "HC01_EST_VC09", "HC01_EST_VC12",
          "HC01_EST_VC13", "HC01_EST_VC16",
          "HC01_EST_VC20", "HC01_EST_VC23",
          "HC01_EST_VC24", "HC01_EST_VC25",
          "HC01_EST_VC26", "HC01_EST_VC27")

data = data[keeps]


write.csv(data, file = "ACS_2011_5YR_S2403_Cleaned.csv")

###############################################################

# S2506

setwd("E:/project_new/S2506")

data = read.csv("ACS_11_5YR_S2506_with_ann.csv")

keeps = c("GEO.id2", "HC01_EST_VC01",  
          "HC01_EST_VC10")

data = data[keeps]

write.csv(data, file = "ACS_2011_5YR_S2506_Cleaned.csv")


###############################################################

# S2507

setwd("E:/project_new/S2507")

data = read.csv("ACS_11_5YR_S2507_with_ann.csv")

keeps = c("GEO.id2", "HC01_EST_VC01",  
          "HC01_EST_VC10")

data = data[keeps]

write.csv(data, file = "ACS_2011_5YR_S2507_Cleaned.csv")

